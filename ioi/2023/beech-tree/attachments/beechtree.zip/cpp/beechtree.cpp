#include "beechtree.h"

std::vector<int> beechtree(int N, int M, std::vector<int> P, std::vector<int> C)
{
    return {};
}
